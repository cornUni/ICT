from Cli.cli import CLI
from Cli.actions.Actions import Action


def main():
    CLI().execute()

    

if __name__ == "__main__":
    main()
